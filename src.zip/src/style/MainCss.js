import styled from "@emotion/styled";

export const MainWrap = styled.div`
max-height: 500px;
`;