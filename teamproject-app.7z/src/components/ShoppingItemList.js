import React from 'react'

const ShoppingItemList = () => {
  return (
    <div>ShoppingItemList</div>
  )
}

export default ShoppingItemList