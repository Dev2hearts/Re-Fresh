import React from "react";

const NotFound = () => {
  return (
    <div className="p-6 m-auto mt-5 shadow rounded bg-white">NotFound</div>
  );
};

export default NotFound;
