// import ItemList from "./ItemList";
import { useState } from "react";
import { ShoppingWrap } from "../style/ShoppingListCss";
import image from "../image/arrow1.png";

const ShoppingList = () => {
  const [isClicked, setIsClicked] = useState(false);
  const handleClick = () => {
    setIsClicked(!isClicked);
  };
  return (
    <ShoppingWrap>
      <div className="listOpen">
        <img src={image} alt="화살표" onClick={handleClick} />
      </div>
    </ShoppingWrap>
  );
};

export default ShoppingList;
