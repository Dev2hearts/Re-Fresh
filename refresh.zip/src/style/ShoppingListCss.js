import styled from "@emotion/styled";

export const ShoppingWrap = styled.div`
  position: relative;
  background: #f9f6f1;
  height: 100vh;
  border-radius: 15px 15px 0 0;
  width: 100%;
  .listOpen {
    display: flex;
    justify-content: center;
    height: 20px;
    img {
      height: 100%;
      margin-top: 10px;
    }
  }
`;
