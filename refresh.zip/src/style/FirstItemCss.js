import styled from "@emotion/styled";

export const ItemBox = styled.div`
  background:#d9d9d9;
  margin: 10px auto;
  width: 90%;
  height: 100px;
  border-radius: 15px;
`;
