# Shopping Todo List Project

## 1. 프로젝트 정보

- [Notion](https://)
- [Figma](https://)
- 기간 : 2023.06.21 ~ 2023.07.13

## 2. 활용 모듈

- React 18
- React Router 6
- Emotion
- SCSS
- Fontawsome
- TailWind
- axios
- AntDesign
- ESLint
- Prettier

## 3. 프로젝트 후기
